$(document).ready(function(){
    $(".cost-calculator-btn").on('click', function(e){
        e.preventDefault();
        $(".popup2, .overlay").show();
    });

    $('.overlay, .closeBtn').on('click', function(){
        $(".popup2, .overlay, .popup1").hide();
    })

    $('.book-appointment').on('click', function(e) {
        e.preventDefault();
        var target = $(this.hash);

        $('html, body').animate({
          scrollTop: target.offset().top
        }, 800);
  
      });

     

    $(".show-more").click(function () {
        const content = $(this).closest("li").find(".more-content").html(); 
        $("#contentModal .modal-body").html(content);
        $("#contentModal").fadeIn();
    });

    $(".close-btn").click(function () {
        $("#contentModal").fadeOut();
    });

    $(window).click(function (e) {
        if ($(e.target).is("#contentModal")) {
            $("#contentModal").fadeOut(); // Hide modal
        }
    });

    $("form").on("submit", function () {
        $("#loader").show(); // Show the loader
    });

    $('.phoneNumber').on('input', function (event) { 
        this.value = this.value.replace(/[^0-9]/g, '');
    });

    $(window).scroll(function () {
        const body = $('body');
        const isMobile = $(window).width() <= 768;
        if (isMobile && $(this).scrollTop() > 500) {
            body.addClass('sticky');
        } else {
            body.removeClass('sticky');
        }
    });
    
    $('#grade-form').on('submit', function (e) {
        $('.radio-option').removeClass('error');
        $('#error-message').hide();
        if (!$('input[name="grade"]:checked').length) {
            e.preventDefault();
            $('.radio-option').addClass('error');
            $('#error-message').show();
            $("#loader, .spinner").hide();
        }
    });

    const videos = document.querySelectorAll('video');

    // Loop through each video and add an event listener for play
    videos.forEach(video => {
        video.addEventListener('play', function() {
            // Pause all other videos when one video starts playing
            videos.forEach(otherVideo => {
                if (otherVideo !== video) {
                    otherVideo.pause();
                }
            });
        });
    });
});